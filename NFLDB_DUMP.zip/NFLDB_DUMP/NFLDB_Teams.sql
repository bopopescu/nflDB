-- MySQL dump 10.13  Distrib 5.7.12, for osx10.9 (x86_64)
--
-- Host: ix.cs.uoregon.edu    Database: NFLDB
-- ------------------------------------------------------
-- Server version	5.6.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Teams`
--

DROP TABLE IF EXISTS `Teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Teams` (
  `team_id` int(11) NOT NULL AUTO_INCREMENT,
  `team_name` varchar(45) NOT NULL,
  `location` varchar(45) NOT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `league_id` int(11) DEFAULT NULL,
  `coach_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`team_id`),
  UNIQUE KEY `team_id_UNIQUE` (`team_id`),
  UNIQUE KEY `team_name_UNIQUE` (`team_name`),
  KEY `ownerFK_idx` (`owner_id`),
  KEY `leagueFK_idx` (`league_id`),
  KEY `fk_Teams_Coaches1_idx` (`coach_id`),
  CONSTRAINT `fk_Teams_Coaches1` FOREIGN KEY (`coach_id`) REFERENCES `Coach` (`coach_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `leagueFK` FOREIGN KEY (`league_id`) REFERENCES `League` (`league_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ownerFK` FOREIGN KEY (`owner_id`) REFERENCES `owners` (`owner_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Teams`
--

LOCK TABLES `Teams` WRITE;
/*!40000 ALTER TABLE `Teams` DISABLE KEYS */;
INSERT INTO `Teams` VALUES (1,'Cardinals','Arizona',1,8,1),(2,'Falcons','Atlanta',2,7,2),(3,'Ravens','Baltimore',3,2,3),(4,'Bills','Buffalo',4,1,4),(5,'Panthers','Carolina',5,7,5),(6,'Bears','Chicago',6,6,6),(7,'Bengals','Cincinnati',7,2,7),(8,'Browns','Cleveland',8,2,8),(9,'Cowboys','Dallas',9,5,9),(10,'Broncos','Denver',10,4,10),(11,'Lions','Detroit',11,6,11),(12,'Packers','Green Bay',12,6,12),(13,'Texans','Houston',13,3,13),(14,'Colts','Indianapolis',14,3,14),(15,'Jaguars','Jacksonville',15,3,15),(16,'Chiefs','Kansas City',16,4,16),(17,'Rams','Los Angeles',17,8,17),(18,'Dolphins','Miami',18,1,18),(19,'Vikings','Minnesota',19,6,19),(20,'Patriots','New England',20,1,20),(21,'Saints','New Orleans',21,7,21),(22,'Giants','New York',22,5,22),(23,'Jets','New York',23,1,23),(24,'Raiders','Oakland',24,4,24),(25,'Eagles','Philadelphia',25,5,25),(26,'Steelers','Pittsburgh',26,2,26),(27,'Chargers','San Diego',27,4,27),(28,'49ers','San Francisco',28,8,28),(29,'Seahawks','Seattle',29,8,29),(30,'Buccaneers','Tampa Bay',30,7,30),(31,'Titans','Tennessee',31,3,31),(32,'Redskins','Washington',32,5,32);
/*!40000 ALTER TABLE `Teams` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-08 18:37:10
